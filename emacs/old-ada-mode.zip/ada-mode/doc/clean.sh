#! /bin/sh
rm ada-mode.aux ada-mode.fn ada-mode.log ada-mode.toc
