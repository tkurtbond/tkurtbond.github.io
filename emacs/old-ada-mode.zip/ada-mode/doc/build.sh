#! /usr/bin/env bash
texi2any -o ada-mode.info --no-split ada-mode.texi
texi2any --html -o ada-mode.html --no-split ada-mode.texi
